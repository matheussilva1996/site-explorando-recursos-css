# curso-alura-arquitetura-css
Projeto feito para o curso de Arquitetura CSS para Alura

Protótipo: https://www.figma.com/file/0gMF5BPgplPYqQA6Om1T1sk9/alura-bootstrap?node-id=0%3A1
